package com.dish.auth.fiegnclient;

public interface UserServiceClient {
}
