package com.dish.auth.service.impl;


import java.util.Optional;
import java.util.UUID;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.dish.auth.configuration.MessageConfig;
import com.dish.auth.constants.Constants;
import com.dish.auth.dto.AuthDto;
import com.dish.auth.entity.AuthEntity;
import com.dish.auth.response.ApiResponse;
import com.dish.auth.respository.AuthRepository;
import com.dish.auth.service.AuthService;
import com.dish.auth.utils.Utility;
import com.dish.auth.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

	private final AuthRepository authRepository;
	private final MessageConfig messageConfig;
	private final Utility utility;
	private final JwtUtil jwtUtil;
	@Value("${realMName}")
	private String realm;

	@Value("${keyClaokClientId}")
	private String clientId;

	@Value("${clientSecretKey}")
	private String clientSecret;

	@Value("${keycloack}")
	private String authServerUrl;
	
  //  private final PasswordEncoder passwordEncoder;


	@Override
	public ApiResponse saveAuth(AuthDto authDto, BindingResult bindingResult) {
		log.debug("*****************Save Auth******************");
		String uuid = UUID.randomUUID().toString();
		log.debug(Constants.REQUEST_ID, uuid);
		try {
			if (bindingResult.hasErrors()) {
				StringBuilder errorMessage = new StringBuilder();
				bindingResult.getAllErrors().forEach(error -> {
					errorMessage.append(error.getDefaultMessage()).append("; ");
				});
				return ApiResponse.builder().data(null).status(Boolean.FALSE).HTTPstatusCode(HttpStatus.BAD_REQUEST)
						.message(errorMessage.toString()).requestId(uuid).build();

			}
			AuthEntity authEntity = new AuthEntity();
			BeanUtils.copyProperties(authDto, authEntity);
			authEntity.setPassword(utility.encodePassword(authDto.getPassword()));
			authRepository.save(authEntity);
			return ApiResponse.builder().data(null).status(Boolean.TRUE).HTTPstatusCode(HttpStatus.OK)
					.message(messageConfig.authDetailsSavedSuccessfully).requestId(uuid).build();
		} catch (DataIntegrityViolationException  e) {
			return ApiResponse.builder().data(null).status(Boolean.FALSE).HTTPstatusCode(HttpStatus.BAD_REQUEST)
					.message(messageConfig.emailDuplicate).requestId(uuid).build();
		} catch (Exception e) {
			log.error("Exception : ()", e.getMessage());
			return ApiResponse.builder().data(null).status(Boolean.FALSE)
					.HTTPstatusCode(HttpStatus.INTERNAL_SERVER_ERROR).message(messageConfig.adminContact).build();
		}
	}
	
	  

	    @Override
	    public ApiResponse login(AuthDto authDto, BindingResult bindingResult) {
	        log.debug("*****************Login******************");
	        String uuid = UUID.randomUUID().toString();
	        log.debug(Constants.REQUEST_ID, uuid);

	        // Check if there are binding errors
	        if (bindingResult.hasErrors()) {
	            StringBuilder errorMessage = new StringBuilder();
	            bindingResult.getAllErrors().forEach(error -> {
	                errorMessage.append(error.getDefaultMessage()).append("; ");
	            });
	            return ApiResponse.builder()
	                    .status(Boolean.FALSE)
	                    .HTTPstatusCode(HttpStatus.BAD_REQUEST)
	                    .message(errorMessage.toString())
	                    .requestId(uuid)
	                    .build();
	        }

	        try {
	            // Find user by email
	            Optional<AuthEntity> authOptional = authRepository.findByEmail(authDto.getEmail());
	            if (!authOptional.isPresent()) {
	                return ApiResponse.builder()
	                        .status(Boolean.FALSE)
	                        .HTTPstatusCode(HttpStatus.UNAUTHORIZED)
	                        .message(messageConfig.invalidCredentials)
	                        .requestId(uuid)
	                        .build();
	            }

	            AuthEntity authEntity = authOptional.get();

	            // Check if encoded password matches the one stored in the database
	            if (!utility.isPasswordMatch(authDto.getPassword(), authEntity.getPassword())) {
	                return ApiResponse.builder()
	                        .status(Boolean.FALSE)
	                        .HTTPstatusCode(HttpStatus.UNAUTHORIZED)
	                        .message(messageConfig.invalidCredentials)
	                        .requestId(uuid)
	                        .build();
	            }

//	            // If authentication successful, generate token using Keycloak
//	            AccessTokenResponse accessTokenResponse = generateToken(authDto.getEmail(), authDto.getPassword());
//	            String token = accessTokenResponse.getToken();
	            String token = jwtUtil.generateToken(authDto.getEmail());
	            return ApiResponse.builder()
	                    .status(Boolean.TRUE)
	                    .HTTPstatusCode(HttpStatus.OK)
	                    .message(messageConfig.loginSuccessful)
	                    .data(token) // Return the generated token
	                    .requestId(uuid)
	                    .build();
	        } catch (Exception e) {
	            log.error("Exception : ()", e.getMessage());
	            return ApiResponse.builder()
	                    .status(Boolean.FALSE)
	                    .HTTPstatusCode(HttpStatus.INTERNAL_SERVER_ERROR)
	                    .message(messageConfig.adminContact)
	                    .requestId(uuid)
	                    .build();
	        }
	    }

	 // Method to generate token using Keycloak
//	    private AccessTokenResponse generateToken(String email, String password) {
//	        try {
//	            Keycloak keycloak = Keycloak.getInstance(
//	                authServerUrl,
//	                realm,
//	                clientId,
//	                clientSecret,
//	                "admin-cli"
//	            );
//
//	            // Get the RealmResource
//	            RealmResource realmResource = keycloak.realm(realm);
//
//	            // Get the UserResource
//	            UserResource userResource = realmResource.users().get(email);
//
//	            // Generate token using Keycloak
//	            AccessTokenResponse accessTokenResponse = keycloak.tokenManager().getAccessToken();
//	            return accessTokenResponse;
//	        } catch (Exception e) {
//	            // Log the exception
//	            log.error("Exception occurred while generating token: {}", e.getMessage());
//	            // You may return null or throw a custom exception here
//	            return null;
//	        }
//	    }

	}