package com.dish.test.mgmt.configuration;

import org.springframework.web.servlet.HandlerInterceptor;

public class RequestInterceptor implements HandlerInterceptor{

}
