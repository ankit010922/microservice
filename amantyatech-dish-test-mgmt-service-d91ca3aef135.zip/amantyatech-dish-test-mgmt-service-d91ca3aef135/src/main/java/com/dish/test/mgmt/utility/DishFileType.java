package com.dish.test.mgmt.utility;

public enum DishFileType {
SCREENSHOT,
LOG,
IPERF
}
