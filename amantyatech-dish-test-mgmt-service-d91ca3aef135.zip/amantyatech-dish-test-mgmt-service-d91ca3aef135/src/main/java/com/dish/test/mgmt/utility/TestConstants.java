package com.dish.test.mgmt.utility;

public interface TestConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILED = "FAILED";

}
