package com.dish.test.mgmt.entity.util;

public interface IdentifiableEntity {
	String getIdPrefix();
}