package com.dish.test.mgmt.constants;

public interface TestManagementEntityPrefixConstants {
public static String DEVICE_BUCKET_PREFIX = "DEVICE-BUCKET";
}
