package com.dish.notification.service;



public interface EmailNotificationService {
	
	public void sendEmailWithOtp(String email);

}
