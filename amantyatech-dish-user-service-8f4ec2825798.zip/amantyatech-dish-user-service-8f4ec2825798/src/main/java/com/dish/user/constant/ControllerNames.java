package com.dish.user.constant;

public class ControllerNames {

	public static final String REGISTER_USER = "/register";
	public static final String USER = "/users";
	public static final String ROLE_MASTER = "/roles";
}
