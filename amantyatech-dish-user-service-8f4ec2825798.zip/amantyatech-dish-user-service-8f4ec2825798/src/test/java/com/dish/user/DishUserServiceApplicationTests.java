package com.dish.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DishUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
