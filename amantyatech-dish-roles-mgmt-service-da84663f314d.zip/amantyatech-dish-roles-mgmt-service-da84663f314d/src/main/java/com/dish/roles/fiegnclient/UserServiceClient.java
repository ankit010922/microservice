package com.dish.roles.fiegnclient;
public interface UserServiceClient {
}
