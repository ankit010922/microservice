package com.dish.roles.enums;

public enum AccessType {
	READ, WRITE, DELETE, ALL, UPDATE
}