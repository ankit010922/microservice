package com.dish.roles.constants;

public interface UrlConstants {

	final static String API_V1 = "api/v1/";
	
	final static String ROLE_CONTROLLER_BASEURL = API_V1+"role/";
	
}
