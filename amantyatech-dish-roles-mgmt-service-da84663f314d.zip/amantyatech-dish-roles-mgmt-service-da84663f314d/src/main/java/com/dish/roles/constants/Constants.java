package com.dish.roles.constants;

public interface Constants {
	public static final String REQUEST_ID = "Request ID for this request: {}";
	public static final String API_RESPONSE = "API_RESPONSE :{} ";

}
