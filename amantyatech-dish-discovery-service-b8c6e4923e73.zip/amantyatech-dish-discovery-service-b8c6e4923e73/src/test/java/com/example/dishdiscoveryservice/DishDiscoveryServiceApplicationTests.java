package com.example.dishdiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DishDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
