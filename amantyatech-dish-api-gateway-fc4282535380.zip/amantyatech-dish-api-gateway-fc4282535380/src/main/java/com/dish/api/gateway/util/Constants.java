package com.dish.api.gateway.util;

public class Constants {

	private Constants() {
	}
	public static final String CURRENTLY_UNAVAILABLE = " is currently unavailable. Please try again later.";
}

