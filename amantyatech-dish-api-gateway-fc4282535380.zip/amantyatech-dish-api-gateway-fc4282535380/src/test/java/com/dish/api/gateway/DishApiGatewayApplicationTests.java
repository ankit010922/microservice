package com.dish.api.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DishApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
